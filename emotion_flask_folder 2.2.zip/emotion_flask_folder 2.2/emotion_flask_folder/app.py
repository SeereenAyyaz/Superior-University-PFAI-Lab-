import os
import cv2
import numpy as np
from flask import Flask, render_template, url_for, jsonify
from tensorflow import keras
import random 

app = Flask(__name__)
app.secret_key = os.environ.get('SESSION_SECRET', 'emotion-detection-secret-key')

EMOTIONS = ['Angry', 'Disgust', 'Fear', 'Happy', 'Sad', 'Surprise', 'Neutral']
CASCADE_PATH = 'haarcascade_frontalface_default.xml'
face_cascade = cv2.CascadeClassifier(CASCADE_PATH)

model = None
MODEL_PATH = os.path.join('models', 'emotion_model.h5')

def load_model():
    global model
    print("--- Model Loading Status ---")
    
    if not os.path.exists(MODEL_PATH):
        print(f"ERROR: Model file not found at '{MODEL_PATH}'.")
        print("Please ensure emotion_model.h5 is inside a folder named 'models'.")
        model = None
    else:
        try:
            model = keras.models.load_model(MODEL_PATH, compile=False)
            print("Model loaded successfully!")
        except Exception as e:
            print(f"FATAL ERROR loading model from '{MODEL_PATH}':")
            print(f"Exception Type: {type(e).__name__}")
            print(f"Error Message: {e}")
            print("This usually means a dependency is missing or the file is corrupted.")
            model = None
            
    if model is None:
        print("Switching to Demo Mode (Random Emotion Guessing).")
    print("----------------------------")

def detect_emotion(image_path):
    if model is None:
        return random.choice(EMOTIONS)
    
    if face_cascade.empty():
        return "Error: Face detector failed to load."

    try:
        img = cv2.imread(image_path)
        if img is None:
            return "Unknown"
        
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
        
        if len(faces) == 0:
            return "No Face Detected"
        
        (x, y, w, h) = faces[0]
        face_roi = gray[y:y+h, x:x+w]
        face_roi = cv2.resize(face_roi, (64, 64))
        face_roi = face_roi.astype('float32') / 255.0
        face_roi = np.reshape(face_roi, (1, 64, 64, 1))
    
        prediction = model.predict(face_roi, verbose=0)
        emotion_idx = np.argmax(prediction)
        
        return EMOTIONS[emotion_idx]
        
    except Exception as e:
        print(f"Runtime Error in detect_emotion for {image_path}: {e}")
        return "Error"
    
def get_images_with_emotions():
    images_folder = os.path.join('static', 'images')
    images_data = []
    
    if not os.path.exists(images_folder):
        os.makedirs(images_folder)
        return images_data
    
    valid_extensions = ('.jpg', '.jpeg', '.png', '.gif', '.bmp')
    
    for filename in os.listdir(images_folder):
        if filename.lower().endswith(valid_extensions):
            image_path = os.path.join(images_folder, filename)
            emotion = detect_emotion(image_path)
            images_data.append({
                'filename': filename,
                'path': url_for('static', filename=f'images/{filename}'),
                'emotion': emotion
            })
    
    return images_data

@app.route('/')
def index():
    demo_mode = model is None
    return render_template('index.html', demo_mode=demo_mode)

@app.route('/scan')
def scan():
    images = get_images_with_emotions()
    return jsonify({'images': images, 'total': len(images)})

if __name__ == '__main__':
    load_model()
    app.run(host='0.0.0.0', port=5000, debug=True)